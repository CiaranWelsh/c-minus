
java -jar antlr-4.13.2-complete.jar src/parser/Cmm.g4 -package parser -no-listener
